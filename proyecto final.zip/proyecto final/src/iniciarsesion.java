
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

public class iniciarsesion {
    private JFrame frame;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JButton btnNewButton_1;
    private JTextField textField_3;
    private JButton btnNewButton_2;
    private JTextField textField_4;
    private JTextField textFieldSearch;
    private JTextField textField_5;
    private JButton btnNewButton_4;
    private JLabel lblNewLabel_1;
    private JTextField textField_8;
    private JPanel panel;
    private JPasswordField passwordField;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                	iniciarsesion window = new iniciarsesion();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public iniciarsesion() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.getContentPane().setBackground(new Color(109, 119, 146));
        frame.setBounds(100, 100, 928, 744);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblNewLabel = new JLabel("Travel Discover");
        lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setBounds(-4, 10, 171, 56);
        frame.getContentPane().add(lblNewLabel);

        textField = new JTextField();
        textField.setBounds(164, 0, 3, 81);
        frame.getContentPane().add(textField);
        textField.setColumns(10);

        textField_1 = new JTextField();
        textField_1.setBounds(-4, 78, 936, 3);
        frame.getContentPane().add(textField_1);
        textField_1.setColumns(10);

        JButton btnNewButton = new JButton("Inicio");
        btnNewButton.setBackground(new Color(14, 94, 171));
        btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        btnNewButton.setBounds(177, 23, 102, 30);
        frame.getContentPane().add(btnNewButton);

        textField_2 = new JTextField();
        textField_2.setBounds(293, 0, 3, 81);
        frame.getContentPane().add(textField_2);
        textField_2.setColumns(10);

        btnNewButton_1 = new JButton("Servicios");
        btnNewButton_1.setBackground(new Color(14, 94, 171));
        btnNewButton_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        btnNewButton_1.setBounds(312, 24, 114, 30);
        frame.getContentPane().add(btnNewButton_1);

        textField_3 = new JTextField();
        textField_3.setBounds(436, 0, 3, 81);
        frame.getContentPane().add(textField_3);
        textField_3.setColumns(10);

        btnNewButton_2 = new JButton("Rese�as");
        btnNewButton_2.setBackground(new Color(14, 94, 171));
        btnNewButton_2.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        btnNewButton_2.setBounds(457, 24, 114, 30);
        frame.getContentPane().add(btnNewButton_2);

        textField_4 = new JTextField();
        textField_4.setBounds(581, 0, 3, 81);
        frame.getContentPane().add(textField_4);
        textField_4.setColumns(10);
        
        textFieldSearch = new JTextField();
        textFieldSearch.setText("Buscador..");
        textFieldSearch.setBounds(600, 24, 171, 30);
        frame.getContentPane().add(textFieldSearch);
        textFieldSearch.setColumns(10);
        
        textField_5 = new JTextField();
        textField_5.setBounds(782, 0, 3, 81);
        frame.getContentPane().add(textField_5);
        textField_5.setColumns(10);
        
        btnNewButton_4 = new JButton();
        btnNewButton_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        btnNewButton_4.setForeground(new Color(255, 255, 255));
        btnNewButton_4.setBounds(806, 11, 89, 58);
        frame.getContentPane().add(btnNewButton_4);
        btnNewButton_4.setActionCommand("");
        btnNewButton_4.setIcon(new ImageIcon("D:\\5 �2\\LPOO\\proyecto pagina\\Imagenes\\registrarse (1).jpg"));
        btnNewButton_4.setBackground(new Color(255, 255, 255));
        btnNewButton_4.setBorder(null);
        btnNewButton_4.setFont(new Font("Arial", Font.BOLD, 30));
        
        lblNewLabel_1 = new JLabel("Contrasenia:");
        lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1.setBounds(251, 429, 145, 35);
        frame.getContentPane().add(lblNewLabel_1);
        
        JLabel lblNewLabel_1_3 = new JLabel("Correo Electronico:");
        lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1_3.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
        lblNewLabel_1_3.setBounds(260, 318, 188, 35);
        frame.getContentPane().add(lblNewLabel_1_3);
        
        JLabel lblNewLabel_2 = new JLabel("Travel Discover");
        lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 34));
        lblNewLabel_2.setBounds(331, 117, 440, 45);
        frame.getContentPane().add(lblNewLabel_2);
        
        
        textField_8 = new JTextField();
        textField_8.setColumns(10);
        textField_8.setBounds(457, 322, 171, 30);
        frame.getContentPane().add(textField_8);
        
        JButton btnEnviar = new JButton("Iniciar");
        btnEnviar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        		try {
					
        			Class.forName("com.mysql.cj.jdbc.Driver");
        			
        			java.sql.Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/traveldiscover","root", "");
        			
        
        			
        				String correo_ini = textField_8.getText();
        				@SuppressWarnings("deprecation")
						String contrasenia_ini = passwordField.getText();
        				
        				
        				String query = "INSERT INTO `logearse`(`correoel`, `contrasena`) VALUES ('"+correo_ini+"','"+contrasenia_ini+"')";
        				
        				Statement stmt = conexion.createStatement();
        				
        				stmt.executeUpdate(query);
        				
        				JOptionPane.showMessageDialog(null, "Bienvenido");
        			
				} catch (Exception e2) {
					System.out.println("Error al conectar a la base de datos");
					e2.printStackTrace();
				}
        		
        	}
        });
        btnEnviar.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        btnEnviar.setBounds(381, 543, 102, 30);
        frame.getContentPane().add(btnEnviar);
        
        panel = new JPanel();
        panel.setBackground(new Color(109, 119, 146));
        panel.setBounds(-4, 0, 916, 81);
        frame.getContentPane().add(panel);
        
        passwordField = new JPasswordField();
        passwordField.setBounds(457, 433, 171, 30);
        frame.getContentPane().add(passwordField);
        
        JLabel lblNewLabel_2_1 = new JLabel("Acceda a su cuenta");
        lblNewLabel_2_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblNewLabel_2_1.setBounds(366, 173, 288, 30);
        frame.getContentPane().add(lblNewLabel_2_1);
        
        JButton btnCrearCuenta = new JButton("Registrarse");
        btnCrearCuenta.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
                registrarse newframe = new registrarse();
                newframe.setVisible(true);
                frame.dispose();
            }
			
        });
        btnCrearCuenta.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        btnCrearCuenta.setBounds(10, 664, 158, 30);
        frame.getContentPane().add(btnCrearCuenta);
        
        JLabel lblNewLabel_1_1 = new JLabel("No tiene cuenta?");
        lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
        lblNewLabel_1_1.setBounds(17, 626, 145, 35);
        frame.getContentPane().add(lblNewLabel_1_1);
        
    }

	public void setVisible(boolean b) {
		frame.setVisible(true);
		
	}
}
